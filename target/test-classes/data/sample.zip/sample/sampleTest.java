package test.cases.__prjName__;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import fwk.__prjName____prjType__;

/**
 * Sample test for SAFE Automation.<p><p>
 * 
 * When running with webapp, this should be running properly, open the browser and navigate to www.hp.com. Otherwise, this is just a sample of what the test should be like.
 * Please follow the SAFE reference Guide and/or other instructions to complete the configurations.
 * 
 */
public class MyFirstTest {

	__prjName____prjType__ ui = null;
	
	@BeforeClass
	public void setUp() {

		ui=new __prjName____prjType__();
		ui.openApp();
        
	}

	/**
	 * Create a new account and verify that the activation view is shown.
	 */
	@Test
	public void test010_verifyHP() {	    
		ui.log("We are running!");     // Good practice to log when each test begins.
		ui.verifyIsShown("hp");
	}

	
	/**
	 * Closes the application. 
	 */
	@AfterClass
    	public void tearDown() {
        	ui.close();
    	}
}
