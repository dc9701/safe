package fwk;

import base.__prjType__;

public class __prjName____prjType__ extends __prjType__{

	public String getAppName() 	{
		return "__prjName__";
	}

	public __prjName____prjType__() {
		this("");
	}

	public __prjName____prjType__(String SUT) {
		this(SUT, "");
	}

	public __prjName____prjType__(String SUT, String profileName) {
		super(SUT, profileName);
	}
}